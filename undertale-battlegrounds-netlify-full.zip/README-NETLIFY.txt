UNDERTALE: BATTLEGROUNDS — NETLIFY PACKAGE

Upload the ZIP directly to Netlify.

This package includes:
- root index.html
- all 29 previously embedded PNG data assets extracted into /assets/embedded
- same-origin proxy routes for the external sprite/audio/font repositories
- service-worker caching for proxied/local assets
- Netlify cache headers
- savedata key documentation; the original localStorage/IndexedDB save code remains intact

The two MQTT WebSocket brokers remain external because multiplayer transport is a live network service, not a static asset.
