SAVE DATA

The game already saves progression/settings in browser localStorage and caches some runtime assets in IndexedDB.
Those APIs remain enabled in this Netlify package.

Important: an existing save from file://, localhost, or another website belongs to that old origin, so it cannot be copied out of the HTML itself. Deploying this package creates a stable Netlify origin where future saves persist normally.
